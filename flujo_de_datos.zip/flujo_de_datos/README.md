## Practica 3 Archivos  (Flujo de datos I/O)

En esta practica vas a crear un programa que nos permita leer un archivo de texto y mostrarle los datos que contiene.
